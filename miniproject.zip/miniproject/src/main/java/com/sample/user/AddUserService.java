package com.sample.user;

import java.util.List;

public class AddUserService {
	
	public List<User> addUser(String firstName, String lastName) {
		System.out.println("User object recieved");
		System.out.println("First Name : " + firstName);
		System.out.println("Last Name : " + lastName);
		User user = new User();
		user.setFirstName(firstName);
		user.setLastName(lastName);
		
		UserDao userDao = new UserDao();
		userDao.addUser(user);
		
		return userDao.selectAllUsers();
	}

}
