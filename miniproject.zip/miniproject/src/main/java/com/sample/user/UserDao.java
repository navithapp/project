package com.sample.user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
//	private String jdbcURL = "jdbc:mysql://localhost:3306/demo?useSSL=false";
	private String jdbcURL = "jdbc:mysql://localhost:3306/user?useSSL=false";
	private String jdbcUsername = "ashni";
	private String jdbcPassword = "ashni@2022";

	private static final String SELECT_ALL_USERS = "select * from user";
	private static final String INSERT_USER = "INSERT INTO user" 
			+ "  (first_name, last_name, phone_number, email, address) VALUES (?, ?, ?, ?, ?);";

	public UserDao() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
	
	public User addUser(User user) {
		System.out.println(INSERT_USER);
        // try-with-resource statement will auto close the connection.
        try (Connection connection = getConnection(); 
        		PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USER)) {
            preparedStatement.setString(1, user.getFirstName());
            preparedStatement.setString(2, user.getLastName());
            preparedStatement.setString(3, user.getPhoneNumber());
            preparedStatement.setString(4, user.getEmail());
            preparedStatement.setString(5, user.getAddress());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
        	System.err.println("Error in adding user");
        }
        return user;
	}

	public List<User> selectAllUsers() {

        // using try-with-resources to avoid closing resources (boiler plate code)
        List<User> users = new ArrayList<User>();
        
        // Step 1: Establishing a Connection
        try (Connection connection = getConnection();
            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_USERS);) {
        	if (connection != null) {
	            System.out.println(preparedStatement);
	            // Step 3: Execute the query or update query
	            ResultSet rs = preparedStatement.executeQuery();
	
	            // Step 4: Process the ResultSet object.
	            while (rs.next()) {
	                int id = rs.getInt("id");
	                String fName = rs.getString("first_name");
	                String lName = rs.getString("last_name");
	                String phoneNumber = rs.getString("phone_number");
	                String email = rs.getString("email");
	                String address = rs.getString("address");
	                users.add(new User(id, fName, lName, phoneNumber, email, address));
	            }
        	}
        } catch (SQLException e) {
            System.err.println("Error in fetching users");
        }
        return users;
    }
}
