package com.sample.user;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(
        name = "adduserservlet",
        urlPatterns = "/AddUser"
)
public class AddUserServlet extends HttpServlet {
	@Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String firstName = req.getParameter("fname");
        String lastName = req.getParameter("lname");

        AddUserService addUserService = new AddUserService();
        List<User> users = addUserService.addUser(firstName, lastName);

        req.setAttribute("users", users);
        RequestDispatcher view = req.getRequestDispatcher("users.jsp");
        view.forward(req, resp);

    }
}
